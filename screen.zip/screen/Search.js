import React, {Component} from 'react';
import {
  TextInput,
  Text,
  Dimensions,
  View,
  Image,
  StyleSheet,
  Button,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from 'lodash';
import {ListItem, Avatar} from 'react-native-elements';
import {getUsers, contains} from '../styles/index';
import UserPost from '../styles/UserPost';

const numColumns = 3;
const DeviceWidth = Dimensions.get('window').width;

export default class Search extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: false,
      data: [],
      fullData: [],
      error: null,
    };

    this.goCall = this.goCall.bind(this);
  }

  goCall() {
    this.props.navigation.navigate('User');
  }

  componentDidMount() {
    this.makeRemoteRequest();
  }

  makeRemoteRequest = _.debounce(() => {
    this.setState({loading: true});

    getUsers(20, this.state.query)
      .then(user => {
        this.setState({
          loading: false,
          data: user,
          fullData: user,
        });
      })
      .catch(error => {
        this.setState({error, loading: false});
      });
  }, 250);

  handleSearch = text => {
    const formattedQuery = text.toLowerCase();
    const data = _.filter(this.state.data, user => {
      return contains(user, formattedQuery);
    });
    this.setState({data, query: text}, () => this.makeRemoteRequest());
  };

  formatData = (data, numColumns) => {
    const totalRows = Math.floor(data.length / numColumns);
    let totalLastRows = data.length - totalRows * numColumns;

    while (totalRows !== 0 && totalLastRows !== numColumns) {
      UserPost.push({key: 'blank', empty: true});
      totalLastRows++;
    }

    return data;
  };

  _renderItem = ({item, index}) => {
    let {itemStyle, itemInvisible, textStyle, numColumns} = styles;

    if (item.empty) {
      return <View style={(itemStyle, itemInvisible)}></View>;
    }

    return (
      <TouchableOpacity style={itemStyle} onPress={() => this.goCall()}>
        <Text style={textStyle}>{item.userName}</Text>
        <Image style={styles.iconRight} source={item.userImg} />
      </TouchableOpacity>
    );
  };

  render() {
    return (
      <View style={{backgroundColor: '#fff', height: '100%'}}>
        <View
          style={{
            borderWidth: 1,
            borderRadius: 5,
            width: 280,
            height: 31,
            top: 12,
            left: 70,
            borderColor: '#cdd5d5',
          }}>
          <TextInput
            style={{backgroundColor: '#fff', fontSize: 10}}
            onChangeText={this.handleSearch}
            value={this.state.query}
          />
        </View>
        <View style={{top: 40}}>
          <FlatList
            data={this.state.data}
            renderItem={this._renderItem}
            keyExtractor={(item, index) => index.toString()}
            numColumns={numColumns}
          />
        </View>
        <View style={{flexDirection: 'row', top: 50}}>
          <Text style={{alignSelf: 'center', left: 190}}>1/2</Text>

          <View style={{left: 308, marginTop: 10, width: 70}}>
            <TouchableOpacity
              style={{
                backgroundColor: 'tranparent',
                marginHorizontal: 170,
                height: 50,
                right: 167,
                top: 10,
              }}>
              <Image
                source={require('../icon/forward.png')}
                style={{height: 30}}
              />
            </TouchableOpacity>
          </View>
          <View style={{right: 80, marginTop: 9, width: 70}}>
            <TouchableOpacity
              style={{
                backgroundColor: 'tranparent',
                marginHorizontal: 170,
                height: 50,
                right: 167,
                top: 10,
              }}>
              <Image
                source={require('../icon/arrow.png')}
                style={{height: 30}}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'space-evenly',
    flexDirection: 'row',
    marginBottom: 10,
    paddingTop: 0,
  },
  avatar: {
    paddingTop: 10,
    width: 130,
    height: 130,
    marginBottom: 50,
    marginLeft: 20,
  },
  logo: {
    width: 66,
    height: 58,
  },
  iconRight: {
    paddingTop: 10,
    width: 65,
    height: 66,
    marginBottom: 30,
    marginLeft: 0,
  },
  button: {
    backgroundColor: 'blue',
    padding: 18,
    width: '46%',
    height: 60,
  },
  input: {
    alignItems: 'center',
    height: 35,
    margin: 0,
    borderWidth: 1,
    paddingBottom: 10,
    paddingHorizontal: 10,
    left: 22,
    borderColor: '#cdd5d5',
  },
  itemStyle: {
    backgroundColor: 'grey',
    alignItems: 'center',
    justifyContent: 'center',
    height: 150,
    flex: 1,
    marginHorizontal: 2,
    marginVertical: 2,
    borderWidth: 18,
    borderColor: '#fff',
  },
  itemInvisible: {
    backgroundColor: 'transparent',
  },
  textStyle: {
    position: 'absolute',
    right: 5,
    bottom: 5,
    backgroundColor: 'white',
    padding: 1,
    fontSize: 10,
  },
});

/* <TouchableOpacity onPress={() => console.log('werk!')}>
<Image
  style={{height: 20, width: 20, right: 360, top: 3}}
  source={require('../icon/icons8-bulleted-list-50.png')}
/>
</TouchableOpacity>
<TouchableOpacity onPress={() => console.log('werk!')}>
<Image
  style={{height: 20, width: 20, right: 340, top: 3}}
  source={require('../icon/icons8-squared-menu-50.png')}
/>
</TouchableOpacity>
<TouchableOpacity onPress={() => console.log('werk!')}>
<Image
  style={{height: 23, width: 23, right: 43, top: 3}}
  source={require('../icon/icons8-scroll-down-50.png')}
/>
</TouchableOpacity> */
