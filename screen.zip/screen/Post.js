import React, {Component} from 'react';
import {
  Container,
  Card,
  Card1,
  UserInfo,
  UserInfo1,
  UserImgWrapper,
  UserImg,
  UserImg1,
  UserInfoText,
  UserName,
  PostTime,
  MessageText,
  MessageText1,
  TextSection,
  PostsImg,
  UserIcon,
} from '../styles/FeedStyles';
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import _ from 'lodash';
import {ListItem, SearchBar, Avatar} from 'react-native-elements';
// import {getUsers, contains} from './api/index';
import {getUsers, contains} from '../styles/index';
import {TextInput, TouchableOpacity} from 'react-native-gesture-handler';

class Post extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: false,
      data: [],
      fullData: [],
      error: null,
    };

    this.goChat = this.goChat.bind(this);
  }

  goChat() {
    let item = this;

    this.props.navigation.navigate('User');
  }

  componentDidMount() {
    this.makeRemoteRequest();
  }

  makeRemoteRequest = _.debounce(() => {
    this.setState({loading: true});

    getUsers(20, this.state.query)
      .then(user => {
        this.setState({
          loading: false,
          data: user,
          fullData: user,
        });
      })
      .catch(error => {
        this.setState({error, loading: false});
      });
  }, 250);

  handleSearch = text => {
    const formattedQuery = text.toLowerCase();
    const data = _.filter(this.state.fullData, user => {
      return contains(user, formattedQuery);
    });
    this.setState({data, query: text}, () => this.makeRemoteRequest());
  };

  renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '86%',
          backgroundColor: '#CED0CE',
          marginLeft: '14%',
        }}
      />
    );
  };

  renderFooter = () => {
    if (!this.state.loading) return null;

    return (
      <View style={{}}>
        <ActivityIndicator animating size="large" />
      </View>
    );
  };

  render() {
    return (
      <View>
        <View
          style={{
            borderWidth: 1,
            borderRadius: 5,
            width: 280,
            height: 41,
            top: 12,
            left: 17,
            borderColor: '#cdd5d5',
          }}>
          <TextInput
            placeholder="Type Here..."
            style={{backgroundColor: '#fff'}}
            onChangeText={this.handleSearch}
            value={this.state.query}
          />
        </View>
        <TouchableOpacity
          style={{
            width: 70,
            height: 35,
            left: 310,
            bottom: 26,
            backgroundColor: '#cdd5d5',
          }}>
          <Text style={{textAlign: 'center', top: 5}}>Post</Text>
        </TouchableOpacity>
        <StatusBar style="light-content" />
        <FlatList
          data={this.state.data}
          keyExtractor={item => item.id}
          renderItem={({item}) => (
            <Card>
              <UserInfo>
                <UserImgWrapper onPress={() => this.goChat()}>
                  <UserImg source={item.userImg} />
                </UserImgWrapper>
                <TextSection>
                  <UserInfoText>
                    <UserName>{item.userName}</UserName>
                    <PostTime>{item.messageTime}</PostTime>
                  </UserInfoText>
                  <MessageText>{item.messageText}</MessageText>
                  <UserImg1 source={item.userImg} />
                </TextSection>
              </UserInfo>
              <UserInfo1>
                <MessageText1>お気に入り (2)</MessageText1>
                <UserIcon source={item.userIcon} />
              </UserInfo1>
            </Card>
          )}
          // keyExtractor={item => item.messageText}
          // ItemSeparatorComponent={this.renderSeparator}

          ListFooterComponent={this.renderFooter}
        />
      </View>
    );
  }
}

export default Post;
